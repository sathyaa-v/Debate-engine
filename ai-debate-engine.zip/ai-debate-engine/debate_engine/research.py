from __future__ import annotations

from .llm import OpenCodeLLM
from .prompts import RESEARCH_PROMPT


def web_research(llm: OpenCodeLLM, topic: str) -> str:
    """Use OpenCode as the research runtime.

    This is deliberately not a direct web client. OpenCode's configured MCP
    servers/tools remain responsible for web access, credentials, and source
    integrations. If no research-capable MCP/tool is configured, OpenCode can
    still return an evidence brief from model knowledge, but the CLI clearly
    labels research as optional.
    """
    return llm.invoke(RESEARCH_PROMPT.format(topic=topic), temperature=0.25)
