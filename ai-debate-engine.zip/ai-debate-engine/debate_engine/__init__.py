"""Multi-agent AI debate engine."""

__version__ = "0.1.0"
