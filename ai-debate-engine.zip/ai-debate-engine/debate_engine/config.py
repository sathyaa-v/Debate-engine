from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any


def _strip_jsonc(text: str) -> str:
    # Good-enough JSONC support for OpenCode config files:
    # remove // comments while preserving quoted strings, then rely on json5
    # for trailing commas/comments when available.
    return text


def _load_json_like(path: Path) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8")
    try:
        import json5
        return json5.loads(text)
    except Exception:
        return json.loads(_strip_jsonc(text))


def discover_opencode_config(explicit: str | None = None) -> Path | None:
    candidates: list[Path] = []
    if explicit:
        candidates.append(Path(explicit).expanduser())

    env_path = os.getenv("OPENCODE_CONFIG")
    if env_path:
        candidates.append(Path(env_path).expanduser())

    cwd = Path.cwd()
    current = cwd
    while True:
        candidates.extend([
            current / "opencode.json",
            current / "opencode.jsonc",
            current / ".opencode" / "opencode.json",
            current / ".opencode" / "opencode.jsonc",
        ])
        if current.parent == current:
            break
        # Stop after reaching the nearest git root, matching normal project use.
        if (current / ".git").exists():
            break
        current = current.parent

    global_dir = Path(os.getenv("XDG_CONFIG_HOME", Path.home() / ".config")) / "opencode"
    candidates.extend([
        global_dir / "opencode.json",
        global_dir / "opencode.jsonc",
    ])

    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return None


def _find_model(data: dict[str, Any]) -> str | None:
    # Current OpenCode uses top-level "model". Keep a small compatibility path
    # for older provider-shaped configs.
    model = data.get("model")
    if isinstance(model, str) and model.strip():
        return model.strip()

    provider = data.get("provider")
    if isinstance(provider, dict):
        for provider_id, provider_cfg in provider.items():
            if not isinstance(provider_cfg, dict):
                continue
            models = provider_cfg.get("models")
            if isinstance(models, dict) and models:
                first = next(iter(models))
                return f"{provider_id}/{first}"
    providers = data.get("providers")
    if isinstance(providers, dict):
        for provider_id, provider_cfg in providers.items():
            if isinstance(provider_cfg, dict):
                models = provider_cfg.get("models")
                if isinstance(models, dict) and models:
                    first = next(iter(models))
                    return f"{provider_id}/{first}"
    return None


@dataclass
class OpenCodeConfig:
    path: Path | None
    model: str | None
    data: dict[str, Any]

    @classmethod
    def load(cls, explicit: str | None = None) -> "OpenCodeConfig":
        path = discover_opencode_config(explicit)
        if not path:
            return cls(None, os.getenv("OPENCODE_MODEL"), {})
        data = _load_json_like(path)
        return cls(path, _find_model(data) or os.getenv("OPENCODE_MODEL"), data)
