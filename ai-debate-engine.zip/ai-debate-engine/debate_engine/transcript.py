from __future__ import annotations

from datetime import datetime
from pathlib import Path
import re

from .models import DebateTurn


def safe_topic(topic: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9]+", "_", topic).strip("_").lower()
    return (slug[:80] or "debate")


def write_transcript(
    output_dir: Path,
    original_topic: str,
    final_topic: str,
    turns: list[DebateTurn],
    judge_history: list[dict],
    final_decision: dict | None,
    partial: bool = False,
) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    suffix = "_PARTIAL" if partial else ""
    path = output_dir / f"debate_{stamp}_{safe_topic(final_topic)}{suffix}.md"

    lines = [
        "# AI Debate Transcript",
        "",
        f"**Original topic:** {original_topic}",
        "",
        f"**Final topic:** {final_topic}",
        "",
        f"**Generated:** {datetime.now().isoformat(timespec='seconds')}",
        "",
        "## Debate",
        "",
    ]
    for turn in turns:
        lines += [f"### Round {turn.round_number} — {turn.side}", "", turn.content, ""]

    if judge_history:
        lines += ["## Judge Checks", ""]
        for idx, judge in enumerate(judge_history, 1):
            lines += [
                f"### Judge check {idx}",
                "",
                f"**Winner:** {judge['winner']}",
                "",
                f"**Confidence:** {judge['confidence']:.0%}",
                "",
                judge["reasoning"],
                "",
                judge["summary_markdown"],
                "",
            ]

    if final_decision:
        lines += [
            "## Final Decision",
            "",
            f"**Winner:** {final_decision['winner']}",
            "",
            f"**Confidence:** {final_decision['confidence']:.0%}",
            "",
            final_decision["reasoning"],
            "",
            final_decision["summary_markdown"],
            "",
        ]

    path.write_text("\n".join(lines), encoding="utf-8")
    return path
