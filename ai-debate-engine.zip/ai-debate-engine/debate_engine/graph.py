from __future__ import annotations

from pathlib import Path
from typing import TypedDict

from langgraph.graph import StateGraph, START, END

from .agents import generate_con, generate_pro
from .judge import judge
from .llm import OpenCodeLLM
from .models import DebateTurn


class DebateState(TypedDict, total=False):
    topic: str
    original_topic: str
    min_rounds: int
    max_rounds: int
    early_stop_confidence: float
    round_number: int
    turns: list[dict]
    judge_history: list[dict]
    winner: str
    confidence: float
    reasoning: str
    summary_markdown: str
    stop: bool
    research: str


def _transcript(turns: list[dict]) -> str:
    return "\n\n".join(
        f"Round {t['round_number']} — {t['side']}:\n{t['content']}" for t in turns
    )


def build_graph(llm: OpenCodeLLM, research: str = ""):
    def pro_node(state: DebateState):
        turns = state.get("turns", [])
        opponent = [t["content"] for t in turns if t["side"] == "Con"]
        own = [t["content"] for t in turns if t["side"] == "Pro"]
        rnd = state["round_number"]
        content = generate_pro(llm, state["topic"], rnd, state["max_rounds"], opponent, own, research)
        return {"turns": turns + [{"round_number": rnd, "side": "Pro", "content": content}]}

    def con_node(state: DebateState):
        turns = state.get("turns", [])
        opponent = [t["content"] for t in turns if t["side"] == "Pro"]
        own = [t["content"] for t in turns if t["side"] == "Con"]
        rnd = state["round_number"]
        content = generate_con(llm, state["topic"], rnd, state["max_rounds"], opponent, own, research)
        return {"turns": turns + [{"round_number": rnd, "side": "Con", "content": content}]}

    def judge_node(state: DebateState):
        decision = judge(llm, state["topic"], _transcript(state["turns"]))
        history = state.get("judge_history", []) + [decision.model_dump()]
        stop = (
            state["round_number"] >= state["min_rounds"]
            and decision.confidence >= state["early_stop_confidence"]
        )
        return {
            "judge_history": history,
            "winner": decision.winner,
            "confidence": decision.confidence,
            "reasoning": decision.reasoning,
            "summary_markdown": decision.summary_markdown,
            "stop": stop,
        }

    def increment_or_end(state: DebateState):
        if state.get("stop") or state["round_number"] >= state["max_rounds"]:
            return "end"
        return "continue"

    def next_round(state: DebateState):
        return {"round_number": state["round_number"] + 1}

    builder = StateGraph(DebateState)
    builder.add_node("pro", pro_node)
    builder.add_node("con", con_node)
    builder.add_node("judge", judge_node)
    builder.add_node("next_round", next_round)
    builder.add_edge(START, "pro")
    builder.add_edge("pro", "con")
    builder.add_conditional_edges("con", lambda s: "judge" if s["round_number"] % 2 == 0 else "next_round",
                                  {"judge": "judge", "next_round": "next_round"})
    builder.add_conditional_edges("judge", increment_or_end, {"end": END, "continue": "next_round"})
    builder.add_edge("next_round", "pro")
    return builder.compile()
