from __future__ import annotations

import json
import subprocess
import time
from dataclasses import dataclass
from typing import Any

from .config import OpenCodeConfig


class LLMError(RuntimeError):
    pass


@dataclass
class OpenCodeLLM:
    config: OpenCodeConfig
    model: str | None = None
    agent: str | None = None
    retries: int = 3

    def _command(self, prompt: str, temperature: float | None = None) -> list[str]:
        cmd = ["opencode", "run", "--format", "json"]
        selected_model = self.model or self.config.model
        if selected_model:
            cmd += ["--model", selected_model]
        if self.agent:
            cmd += ["--agent", self.agent]
        # OpenCode itself owns provider authentication/configuration.
        cmd += [prompt]
        return cmd

    @staticmethod
    def _extract_text(stdout: str) -> str:
        # --format json emits JSON events. We collect assistant text-like fields
        # and fall back to plain output if a provider emits non-event text.
        chunks: list[str] = []
        for line in stdout.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue

            def walk(value: Any):
                if isinstance(value, dict):
                    # Common OpenCode event/message shapes.
                    for key in ("text", "content", "output"):
                        item = value.get(key)
                        if isinstance(item, str) and item.strip():
                            chunks.append(item)
                    for child in value.values():
                        walk(child)
                elif isinstance(value, list):
                    for child in value:
                        walk(child)

            walk(event)

        if chunks:
            # Preserve order but remove exact duplicate fragments.
            out: list[str] = []
            for chunk in chunks:
                if not out or chunk != out[-1]:
                    out.append(chunk)
            return "\n".join(out).strip()

        return stdout.strip()

    def invoke(self, prompt: str, temperature: float | None = None) -> str:
        last_error: Exception | None = None
        for attempt in range(1, self.retries + 1):
            try:
                result = subprocess.run(
                    self._command(prompt, temperature),
                    text=True,
                    capture_output=True,
                    check=False,
                    timeout=600,
                )
                if result.returncode != 0:
                    raise LLMError(result.stderr.strip() or "OpenCode returned a non-zero exit code.")
                text = self._extract_text(result.stdout)
                if not text:
                    raise LLMError("OpenCode returned no model text.")
                return text
            except Exception as exc:
                last_error = exc
                if attempt < self.retries:
                    time.sleep(2 ** (attempt - 1))
        raise LLMError(f"LLM call failed after {self.retries} attempts: {last_error}")
