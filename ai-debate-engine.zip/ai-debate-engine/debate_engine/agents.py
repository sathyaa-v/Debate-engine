from __future__ import annotations

from .llm import OpenCodeLLM
from .prompts import PRO_PROMPT, CON_PROMPT


def dynamic_temperature(round_number: int, max_rounds: int) -> float:
    progress = max(0.0, min(1.0, (round_number - 1) / max(1, max_rounds - 1)))
    return max(0.30, min(0.85, 0.85 - (progress * 0.55)))


def _format_context(items: list[str]) -> str:
    return "\n\n".join(items[-8:]) if items else "(none yet)"


def generate_pro(llm: OpenCodeLLM, topic: str, round_number: int, max_rounds: int,
                 opponent: list[str], own: list[str], research: str = "") -> str:
    context = _format_context(opponent)
    if research:
        context += "\n\nResearch brief:\n" + research
    return llm.invoke(
        PRO_PROMPT.format(
            topic=topic, opponent_context=context, own_context=_format_context(own),
            round_number=round_number
        ),
        temperature=dynamic_temperature(round_number, max_rounds),
    )


def generate_con(llm: OpenCodeLLM, topic: str, round_number: int, max_rounds: int,
                 opponent: list[str], own: list[str], research: str = "") -> str:
    context = _format_context(opponent)
    if research:
        context += "\n\nResearch brief:\n" + research
    return llm.invoke(
        CON_PROMPT.format(
            topic=topic, opponent_context=context, own_context=_format_context(own),
            round_number=round_number
        ),
        temperature=dynamic_temperature(round_number, max_rounds),
    )
