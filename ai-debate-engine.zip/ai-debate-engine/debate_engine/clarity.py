from __future__ import annotations

import json
from .llm import OpenCodeLLM
from .models import ClarityAssessment
from .prompts import CLARITY_PROMPT, REFINE_PROMPT


def _parse_json(text: str) -> dict:
    text = text.strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[1]
        text = text.rsplit("```", 1)[0]
    return json.loads(text)


def assess_topic(llm: OpenCodeLLM, topic: str) -> ClarityAssessment:
    raw = llm.invoke(CLARITY_PROMPT.format(topic=topic), temperature=0.35)
    data = _parse_json(raw)
    assessment = ClarityAssessment.model_validate(data)
    if assessment.score >= 0.72:
        assessment.is_clear = True
    return assessment


def refine_topic(llm: OpenCodeLLM, topic: str, answers: list[tuple[str, str]]) -> str:
    answer_text = "\n".join(f"Q: {q}\nA: {a}" for q, a in answers)
    return llm.invoke(REFINE_PROMPT.format(topic=topic, answers=answer_text), temperature=0.25).strip()
