from __future__ import annotations

import json

from .llm import OpenCodeLLM
from .models import JudgeDecision
from .prompts import JUDGE_PROMPT


def _parse_json(text: str) -> dict:
    text = text.strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[1]
        text = text.rsplit("```", 1)[0]
    return json.loads(text)


def judge(llm: OpenCodeLLM, topic: str, transcript: str) -> JudgeDecision:
    raw = llm.invoke(JUDGE_PROMPT.format(topic=topic, transcript=transcript), temperature=0.20)
    return JudgeDecision.model_validate(_parse_json(raw))
