from __future__ import annotations

from typing import Literal
from pydantic import BaseModel, Field


Winner = Literal["Pro", "Con", "Draw"]


class ClarityAssessment(BaseModel):
    score: float = Field(ge=0.0, le=1.0)
    is_clear: bool
    questions: list[str] = Field(default_factory=list, max_length=3)
    rationale: str


class JudgeDecision(BaseModel):
    winner: Winner
    confidence: float = Field(ge=0.0, le=1.0)
    reasoning: str
    summary_markdown: str


class DebateTurn(BaseModel):
    round_number: int
    side: Literal["Pro", "Con"]
    content: str


class DebateResult(BaseModel):
    original_topic: str
    final_topic: str
    winner: Winner
    confidence: float
    reasoning: str
    summary_markdown: str
    rounds_completed: int
    transcript_path: str
