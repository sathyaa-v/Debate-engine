from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .clarity import assess_topic, refine_topic
from .config import OpenCodeConfig
from .graph import build_graph
from .llm import OpenCodeLLM, LLMError
from .research import web_research
from .transcript import write_transcript


def parse_args():
    p = argparse.ArgumentParser(description="Multi-agent AI debate engine using OpenCode.")
    p.add_argument("--topic", help="Debate topic.")
    p.add_argument("--min-rounds", type=int, default=4)
    p.add_argument("--max-rounds", type=int, default=8)
    p.add_argument("--early-stop-confidence", type=float, default=0.82)
    p.add_argument("--model", help="OpenCode provider/model override.")
    p.add_argument("--agent", help="OpenCode agent override.")
    p.add_argument("--config", help="Explicit OpenCode config path.")
    p.add_argument("--research", action="store_true",
                   help="Ask OpenCode to perform web/MCP research before debating.")
    p.add_argument("--output-dir", default="debate_transcripts")
    return p.parse_args()


def main() -> int:
    args = parse_args()
    if args.min_rounds < 1 or args.max_rounds < args.min_rounds:
        print("Invalid round configuration.", file=sys.stderr)
        return 2

    topic = args.topic or input("Debate topic: ").strip()
    if not topic:
        print("A topic is required.", file=sys.stderr)
        return 2

    cfg = OpenCodeConfig.load(args.config)
    llm = OpenCodeLLM(cfg, model=args.model, agent=args.agent)

    print(f"OpenCode config: {cfg.path or '(not found; using OpenCode defaults)'}")
    print(f"Model: {args.model or cfg.model or '(OpenCode default)'}")
    print("\nChecking topic clarity...")

    try:
        assessment = assess_topic(llm, topic)
    except LLMError as exc:
        print(f"LLM error: {exc}", file=sys.stderr)
        return 1

    print(f"Clarity score: {assessment.score:.0%}")
    final_topic = topic

    if assessment.score < 0.72:
        print("\nThe topic needs clarification.")
        answers = []
        for question in assessment.questions[:3]:
            answer = input(f"\n{question}\n> ").strip()
            answers.append((question, answer))
        if answers:
            final_topic = refine_topic(llm, topic, answers)
            print(f"\nRefined topic: {final_topic}")

    research = ""
    if args.research:
        print("\nResearching with OpenCode/MCP tools...")
        research = web_research(llm, final_topic)

    print("\nStarting debate...")
    print(f"Rounds: {args.min_rounds} minimum / {args.max_rounds} maximum")
    print(f"Early-stop confidence: {args.early_stop_confidence:.0%}\n")

    graph = build_graph(llm, research=research)
    initial = {
        "topic": final_topic,
        "original_topic": topic,
        "min_rounds": args.min_rounds,
        "max_rounds": args.max_rounds,
        "early_stop_confidence": args.early_stop_confidence,
        "round_number": 1,
        "turns": [],
        "judge_history": [],
        "research": research,
        "stop": False,
    }

    state = initial
    transcript_path = None
    try:
        # Stream node updates so the CLI remains visibly live.
        for update in graph.stream(initial, stream_mode="updates"):
            state.update(next(iter(update.values())))
            for node, payload in update.items():
                if node == "pro":
                    print(f"[Round {state['round_number']}] PRO completed")
                elif node == "con":
                    print(f"[Round {state['round_number']}] CON completed")
                elif node == "judge":
                    print(f"[Judge] {payload['winner']} | confidence {payload['confidence']:.0%}")
                elif node == "next_round":
                    print(f"--- moving to round {state['round_number']} ---")

        turns = state.get("turns", [])
        transcript_path = write_transcript(
            Path(args.output_dir),
            topic,
            final_topic,
            [__import__("debate_engine.models", fromlist=["DebateTurn"]).DebateTurn.model_validate(t)
             for t in turns],
            state.get("judge_history", []),
            {
                "winner": state.get("winner", "Draw"),
                "confidence": state.get("confidence", 0.0),
                "reasoning": state.get("reasoning", ""),
                "summary_markdown": state.get("summary_markdown", ""),
            },
        )
    except Exception:
        # Save everything gathered so far before propagating the failure.
        turns = state.get("turns", [])
        transcript_path = write_transcript(
            Path(args.output_dir), topic, final_topic,
            [__import__("debate_engine.models", fromlist=["DebateTurn"]).DebateTurn.model_validate(t)
             for t in turns],
            state.get("judge_history", []), None, partial=True,
        )
        print(f"\nDebate failed. Partial transcript saved to: {transcript_path}", file=sys.stderr)
        raise

    print("\n=== FINAL DECISION ===")
    print(f"Winner: {state.get('winner', 'Draw')}")
    print(f"Confidence: {state.get('confidence', 0.0):.0%}")
    print(f"Rounds completed: {max((t['round_number'] for t in state.get('turns', [])), default=0)}")
    print(f"\n{state.get('reasoning', '')}\n")
    print(state.get("summary_markdown", ""))
    print(f"\nTranscript: {transcript_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
