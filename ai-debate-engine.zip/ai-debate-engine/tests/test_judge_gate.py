def should_stop(round_number, min_rounds, confidence, threshold):
    return round_number >= min_rounds and confidence >= threshold


def test_cannot_stop_before_min_rounds():
    assert not should_stop(2, 4, 0.99, 0.82)


def test_can_stop_after_min_rounds_and_threshold():
    assert should_stop(4, 4, 0.82, 0.82)


def test_cannot_stop_on_low_confidence():
    assert not should_stop(4, 4, 0.81, 0.82)
