import json
from pathlib import Path

from debate_engine.config import OpenCodeConfig


def test_model_is_read(tmp_path, monkeypatch):
    path = tmp_path / "opencode.json"
    path.write_text(json.dumps({"model": "foo/bar"}), encoding="utf-8")
    cfg = OpenCodeConfig.load(str(path))
    assert cfg.model == "foo/bar"
