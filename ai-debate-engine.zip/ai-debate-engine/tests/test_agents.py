from debate_engine.agents import dynamic_temperature


def test_temperature_starts_high():
    assert dynamic_temperature(1, 8) == 0.85


def test_temperature_declines():
    assert dynamic_temperature(4, 8) < dynamic_temperature(2, 8)


def test_temperature_is_clamped():
    assert dynamic_temperature(100, 8) == 0.30
