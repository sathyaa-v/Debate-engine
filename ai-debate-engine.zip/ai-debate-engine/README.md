# AI Debate Engine

A CLI multi-agent debate engine based on the supplied Multi-Agent Debate System requirements.

It uses **LangGraph for orchestration** and **OpenCode as the LLM runtime**. This is intentional: the engine does not duplicate OpenCode provider authentication. OpenCode supplies the configured provider/model and, when enabled, MCP tools.

## Features

- Pro agent argues for the topic.
- Con agent argues against it.
- Neutral Judge evaluates every 2 rounds.
- Clarity score before debate.
- Interactive 1–3 clarification questions when clarity is below 0.72.
- Minimum 4 rounds by default.
- Maximum 8 rounds by default.
- Early stopping only when minimum rounds are reached AND Judge confidence >= 0.82.
- Dynamic temperature from 0.85 toward 0.30.
- Opponent-aware context.
- Retry up to 3 times.
- Partial Markdown transcript on failure.
- Final winner, confidence, reasoning, and summary table.
- Optional web/MCP research through OpenCode.

## Requirements

- Python 3.11+
- OpenCode installed and working from the terminal.
- A configured OpenCode model/provider.

Install Python dependencies:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Windows PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

## OpenCode configuration

The engine discovers configuration in this order:

1. `--config PATH`
2. `OPENCODE_CONFIG`
3. project `opencode.json` / `opencode.jsonc`
4. project `.opencode/opencode.json` / `.jsonc`
5. global `~/.config/opencode/opencode.json` / `.jsonc`

The engine primarily needs the configured model. Provider credentials remain under OpenCode's control.

Example:

```json
{
  "$schema": "https://opencode.ai/config.json",
  "model": "myprovider/my-model",
  "provider": {
    "myprovider": {
      "npm": "@ai-sdk/openai-compatible",
      "name": "My Provider",
      "options": {
        "baseURL": "https://api.example.com/v1",
        "apiKey": "{env:MY_PROVIDER_API_KEY}"
      },
      "models": {
        "my-model": {
          "name": "My Model"
        }
      }
    }
  }
}
```

You can also override the model:

```bash
python debate_engine.py --model provider/model --topic "Is remote work better than office work?"
```

## Run

Basic:

```bash
python debate_engine.py   --topic "Should companies fully replace junior developers with AI agents by 2028?"
```

Longer debate:

```bash
python debate_engine.py   --topic "Is remote work better than office work?"   --min-rounds 6
```

Custom maximum:

```bash
python debate_engine.py   --topic "..."   --min-rounds 4   --max-rounds 8
```

Interactive clarification is automatic.

## Web research

Enable:

```bash
python debate_engine.py   --topic "Should nuclear power be expanded globally?"   --research
```

Research is performed through `opencode run`, so OpenCode's configured MCP servers/tools are available to the research prompt.

For example, configure a web-capable MCP server in OpenCode:

```json
{
  "$schema": "https://opencode.ai/config.json",
  "mcp": {
    "web-research": {
      "type": "remote",
      "url": "https://your-mcp-server.example.com/mcp",
      "enabled": true
    }
  }
}
```

The engine deliberately does not hard-code a specific search vendor. This keeps it compatible with whatever MCP/web research service you already use with OpenCode.

## Output

Transcripts are written to:

```text
debate_transcripts/
  debate_YYYYMMDD_HHMMSS_topic.md
```

If the run fails after producing debate content:

```text
debate_YYYYMMDD_HHMMSS_topic_PARTIAL.md
```

## Architecture

```text
CLI
 |
 +-- OpenCode configuration discovery
 |
 +-- Clarity Agent
 |
 +-- optional OpenCode/MCP Research
 |
 +-- LangGraph
      |
      +-- Pro
      |
      +-- Con
      |
      +-- Judge (round 2, 4, 6, ...)
      |
      +-- early-stop gate
 |
 +-- Markdown transcript
```

## Important OpenCode integration detail

The Python engine invokes the OpenCode CLI rather than trying to reconstruct OpenCode's internal provider/authentication system. This means credentials, custom providers, model routing, and MCP configuration stay in OpenCode.

The engine uses:

```bash
opencode run --format json ...
```

and extracts model text from the JSON event stream.

If your OpenCode installation uses a custom binary name or wrapper, modify `debate_engine/llm.py`.

## Tests

Run:

```bash
pytest -q
```

The tests focus on deterministic engine logic and do not require an LLM call.
