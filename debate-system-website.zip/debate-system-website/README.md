# The Debate Engine — Website

A single, self-contained HTML file explaining the Multi-Agent Debate
System: what it is, why it exists, how it runs, and when to use it — in
plain English first, technical detail second. Includes a client-side,
scripted debate simulator and the real Python engine + write-up as
downloads.

**No Tailwind. No build step. No local server required** — open
`index.html` directly and everything works.

## Folder structure

```
debate-system-website/
├── index.html                        # the entire site — HTML, CSS, and JS
│                                      #   all in one file, nothing to build
├── docs/
│   ├── debate_engine.py              # the real LangGraph engine (downloadable from the page)
│   ├── multi-agent-debate-system.md  # the full technical write-up (downloadable)
│   └── requirements.txt              # pip deps for debate_engine.py
└── README.md                         # this file
```

`index.html` is fully self-contained: every style rule lives in an
inline `<style>` block (hand-written CSS, no framework) and all
interaction logic lives in an inline `<script>` block at the bottom of
the file. The only things it reaches out to the network for are
optional — Google Fonts, jQuery, and Three.js load from CDN for nicer
type and the hero animation, but the page's layout, color, and
structure don't depend on any of them loading. If you're offline, the
site still renders correctly in system fonts with the interactive JS
features simply inactive.

## How to run it

Just open it. That's the whole instruction:

```bash
open index.html          # macOS
xdg-open index.html      # Linux
# or double-click index.html on Windows
```

No `python -m http.server`, no `npx serve`, no build tooling. A local
server is optional, not required — useful only if you want to test from
a different device on your network:

```bash
python -m http.server 8080
# then visit http://localhost:8080
```

## Running the actual engine (not just the simulator)

The page's "Try it" section is a **scripted, client-side simulator** —
it demonstrates pacing and structure with no API key required. To run a
real debate:

```bash
cd docs
pip install -r requirements.txt

python debate_engine.py \
  --topic "Should companies go fully remote?" \
  --rounds 4

# Non-interactive (skips clarifying-question prompts, useful in CI)
python debate_engine.py --topic "..." --non-interactive

# Point at a LiteLLM proxy or any OpenAI-compatible endpoint
python debate_engine.py --topic "..." --base-url http://localhost:4000/v1
```

## Page sections

| Section | What it covers |
|---|---|
| Hero | One-line pitch + the Three.js debate-arena animation |
| For absolutely anyone | Non-technical analogy — no jargon, for anyone regardless of background |
| Why | The problem with a single confident AI answer, with an interactive before/after comparison |
| What | The six features, as clickable detail cards |
| How | The real round-by-round flow, as an ordered timeline (not decorative numbering — it's the actual sequence) |
| Try it | The in-browser scripted simulator |
| When | Good-fit vs. skip-it use cases |
| Under the hood | Accordion of real implementation detail (LangGraph, Pydantic schemas, message roles, retries, config) |
| Code | Folder structure, commands, and direct downloads of the engine + write-up |

## Why no Tailwind

The site previously loaded Tailwind's CDN build plus a runtime JIT
config script. That's an external dependency for something as basic as
styling: if the CDN is slow, blocked, or unreachable, the whole page
loses its layout and colors — whether that's a locked-down network, an
offline demo, or just a flaky connection. All of that CSS is now
hand-written and inlined directly in `index.html`, so the page's
appearance never depends on a third-party script loading successfully.

## Accessibility & performance notes

- Respects `prefers-reduced-motion`: the Three.js scene renders one
  static frame instead of animating, and scroll-reveal/CSS transitions
  collapse to near-instant.
- All interactive elements (accordion, feature cards, simulator, nav)
  work with tap as well as click — nothing is hover-only.
- Particle counts in the hero animation scale down automatically under a
  768px viewport width to stay smooth on phones.
- Visible focus states throughout (`:focus-visible`), a skip-to-content
  link, and `aria-expanded`/`aria-selected` on interactive controls.

## Notes

- jQuery and Three.js still load from CDN (cdnjs) since they're
  behavior, not layout — the page's appearance doesn't depend on them,
  only its animation and interactivity do.
- The simulator's dialogue is hand-written and fixed per topic; it's
  meant to show the *shape* of a debate (temperature dropping, judge
  withholding until confidence clears 82%), not to generate new
  arguments.
