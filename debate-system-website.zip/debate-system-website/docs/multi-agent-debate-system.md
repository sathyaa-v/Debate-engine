# Multi-Agent Debate System

> Two AI agents debate a topic for a fixed number of rounds. Only once every
> round is done does a neutral Judge step in — once — and it has to back a
> side.

---

## 1. Simple Explanation (For Everyone)

Imagine you have an important decision to make, but you only hear one side
of the story.

Now imagine, instead, you invite **two smart people** who disagree with each
other to argue the topic in front of you. One strongly supports the idea.
The other strongly opposes it. They go back and forth for a set number of
rounds — nobody interrupts, nobody peeks at the scoreboard partway through.

Only once they're both finished does a **neutral referee** step in. The
referee looks at everything that was said, from start to finish, and then
does one thing: picks a side. Not "it's close," not "let's hear more" —
a decision, with reasoning and a confidence score attached.

That's this system — with AI agents instead of humans.

### Why this is useful
- Reduces one-sided or biased answers from a single AI
- Forces deeper reasoning through disagreement, uninterrupted
- The judge's read isn't contaminated by checking in mid-debate — it forms
  one opinion, once, from the complete case
- Produces a structured, decision-ready output instead of a long wall of
  text
- Always ends in an actual decision — the judge cannot shrug and call it a
  draw

---

## 2. What the System Does

| Component      | Role                                                        |
|-----------------|--------------------------------------------------------------|
| **Agent Pro**   | Argues *in favor* of the topic                               |
| **Agent Con**   | Argues *against* the topic                                   |
| **Judge**       | Reads the entire finished transcript once and picks a winner |

### Key Features

- **Clarity Check** first — if the topic is vague, it asks clarifying
  questions
- **Dynamic temperature** — agents are more creative early and more
  focused later
- **No interim judging** — the judge doesn't see the transcript until every
  round is done; there's no early stopping and no going back for "just one
  more round"
- **Forced decision** — the judge must back Pro or Con. There is no "Draw"
  option in its schema
- **Full transcript** saved as a clean Markdown file (including partial
  transcripts if a run fails midway)
- **Confidence score** (0–100%) with reasoning — confidence can be modest
  if the case was close, but a side still has to be picked
- **Opponent-aware agents** — each side sees the other's arguments as an
  opponent's statements, not as its own prior output, so rebuttals engage
  with what was actually said

---

## 3. When to Use It

**Good use cases:**
- Important product or architecture decisions
- Evaluating controversial or high-stakes topics
- Reducing bias when asking an AI for advice
- Generating balanced analysis for reports or presentations
- Exploring both sides of a business, ethical, or technical question

**Not ideal for:**
- Simple factual questions
- Creative writing or brainstorming (use other tools)
- Extremely time-sensitive answers
- Situations where a genuine tie is an acceptable answer — this system
  will not give you one

---

## 4. How the Workflow Works

```
User provides a topic
        ↓
Clarity Scoring
        ↓
Is the topic clear?
   ↙          ↘
 Yes           No → Ask clarifying questions → Refine topic
                     (interactive mode only; non-interactive mode
                      proceeds with the original topic)
  ↓
Start Debate
  ↓
Pro → Con → Pro → Con → … (repeats for exactly `rounds` exchanges,
                            no judge involvement at all during this)
  ↓
All rounds complete
  ↓
Judge reads the FULL transcript once
  ↓
Judge commits to Pro or Con (no draw, no re-run)
  ↓
Final Decision + Summary Table + Transcript.md
```

---

## 5. Technical Architecture

### Recommended Hybrid Design

```
OpenCode (or any chat interface)
          ↓
    Calls Python Engine
          ↓
   LangGraph Debate Graph
     ├── Pro Agent
     ├── Con Agent
     └── Judge Agent (runs once, at the end, then the graph ends)
```

Why hybrid?
- OpenCode / UI gives a nice experience
- Python + LangGraph gives precise control, structured output, and
  reproducibility

For a UI/API caller specifically, use the two-phase clarification functions
(`get_clarifying_questions` then `resolve_topic`) rather than `run_debate`,
since `run_debate`'s interactive mode blocks on `input()` and isn't
suitable behind a request/response boundary. Pass `non_interactive=True`
to `run_debate` (or use `run_debate_graph` directly) if you don't want to
implement the clarification round-trip.

### Core Technologies
- **LangGraph** — stateful multi-agent orchestration
- **Pydantic** — structured outputs (Judge decision, Clarity assessment)
- **LiteLLM / OpenAI-compatible API** — model flexibility via `--model` /
  `--base-url` / `--api-key` CLI flags (or `DEBATE_MODEL` / `OPENAI_BASE_URL`
  / `OPENAI_API_KEY` env vars)
- Dynamic temperature scaling
- Markdown transcript generation

---

## 6. Implementation Details

### Clarity Scoring Logic
Before the debate starts, the system scores the topic from 0.0 to 1.0.

- ≥ 0.72 → Start debate immediately
- < 0.72 → Ask 1–3 clarifying questions, then rewrite a clearer version of
  the topic (interactive mode), or proceed with the original topic
  (non-interactive mode)

### Dynamic Temperature
```
Early rounds  → higher temperature (more exploratory)
Later rounds  → lower temperature (more convergent)
```

Formula used:
```python
temp = 0.85 - (progress * 0.55)   # clamped between 0.30 and 0.85
```

### Judge Behavior
- Runs **exactly once**, only after all `rounds` are complete — there is no
  loop back to Pro, no confidence-gated early stop, no interim checkpoint
  every few rounds
- The graph edge from the judge goes straight to `END`
- `JudgeDecision.winner` is typed `Literal["Pro", "Con"]` — there is no
  "Draw" value the model can return, so the schema itself forces a pick
- The prompt explicitly tells the judge a modest confidence score (e.g.
  55–65%) is fine for a close case, but a side must still be chosen
- Returns:
  - Winner (Pro or Con — never a draw)
  - Confidence score
  - Reasoning
  - Summary Markdown table

### Message Roles
Each agent's view of the transcript is built relative to itself: its own
prior turns are treated as assistant messages, and the opponent's turns are
treated as user messages. This keeps Pro and Con arguing with each other
instead of each side effectively continuing its own monologue. The judge
never appears mid-transcript, since it only ever speaks once, at the very
end.

### Error Handling
LLM calls are retried up to 3 times with backoff. If a run still fails
(e.g. persistent API outage), the transcript gathered so far is saved to
`debate_transcripts/..._PARTIAL.md` before the error is raised, so no
in-progress debate is silently lost.

### Output
- Live progress in the terminal
- Final decision + confidence
- Summary table
- Full transcript saved to `debate_transcripts/debate_YYYYMMDD_HHMMSS_topic.md`
  (or `..._PARTIAL.md` on failure)

---

## 7. How to Run

```bash
# Basic usage — 4 rounds (default), then one judge verdict
python debate_engine.py --topic "Should companies fully replace junior developers with AI agents by 2028?"

# More rounds before the judge weighs in
python debate_engine.py --topic "Is remote work better than office work?" --rounds 6

# Point at a LiteLLM proxy or other OpenAI-compatible endpoint
python debate_engine.py --topic "..." --model gpt-4o --base-url http://localhost:4000/v1 --api-key sk-...

# Skip interactive clarifying-question prompts (for scripted/CI use)
python debate_engine.py --topic "..." --non-interactive
```

### Requirements
```bash
pip install -r requirements.txt
```
(pins `langgraph`, `langchain-openai`, `langchain-core`, `pydantic`)

---

## 8. Design Decisions Summary

| Decision                       | Reason                                                        |
|---------------------------------|----------------------------------------------------------------|
| Two opposing agents              | Forces deeper reasoning through conflict                       |
| Separate Judge                   | Neutral evaluation + structured decision                       |
| Judge runs once, at the end      | Its read isn't contaminated by mid-debate checkpoints or a temptation to call it early |
| Fixed round count, no early stop | Both sides always get the full, agreed-upon airing before anyone judges |
| Forced Pro/Con decision, no Draw | A hedge isn't a decision — the schema makes a tie impossible   |
| Clarity check first               | Improves debate quality on vague topics                        |
| Dynamic temperature              | Exploration early, precision later                              |
| Per-agent message roles          | Keeps Pro/Con genuinely responding to each other                |
| Retry + partial save             | Survives transient API failures without losing progress        |
| Markdown transcript              | Easy to share, review, and archive                              |

---

## 9. Future Improvements

- Stream the debate live into a web UI (the `on_update` callback in
  `run_debate_graph` is a starting point)
- Support different persona pairs (Technical vs Business, Optimistic vs
  Pessimistic)
- Multiple judges voting on the same finished transcript, majority wins
- Cost & token tracking
- Web UI with real-time agent messages

---

*Document generated for the Multi-Agent Debate System project.*
